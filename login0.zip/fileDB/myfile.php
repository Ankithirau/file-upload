<?php
$name = $_FILES['f']['name'];
$type = $_FILES['f']['type'];
$size = $_FILES['f']['size'];
$data = $_REQUEST['txt1'];
echo "name is $name"."type is ".$type. " size is ".$size."<br>";
$conn = mysqli_connect('localhost',"root","","6to7");
if($type=="image/png" || $type== "image/jpg" || $type== "image/jpeg")
{
if(move_uploaded_file($_FILES['f']['tmp_name'],"uploads/".$name))
{
	$res = mysqli_query($conn, "insert into fileuploads(fname,fdesc) values('$name','$data')");
	if(mysqli_affected_rows($conn)>0)
	{
		header('location:index.php');
	}
	else
	{
		echo "problem in data insertion";
	}
}
}
else if($type=="text/plain")
{
if(move_uploaded_file($_FILES['f']['tmp_name'],"testdata/".$name))
{
	$res = mysqli_query($conn, "insert into fileuploads(fname,fdesc) values('$name','$data')");
	if(mysqli_affected_rows($conn)>0)
	{
		header('location:index.php');
	}
	else
	{
		echo "problem in data insertion";
	}
}
}
else
{
echo "Image extension should be .jpg or png";
}
?>