<?php
$name = $_REQUEST['q']."%";
$conn= mysqli_connect('localhost','root','','6to7');
$res = mysqli_query($conn,"select * from student where sname like '$name' or  semail like '$name' ");
while($x= mysqli_fetch_array($res))
{
  echo $x[0]." ".$x[1] . " ".$x[2]." ".$x[3]. "<br>";
}
?>