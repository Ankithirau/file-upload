<form action="loginphp.php">
	<label>email</label><br>
	<input type="" name="em" autocomplete="on"><br>
	<label>password</label><br>
	<input type="" name="ps" autocomplete="on"><br>
	<input type="checkbox" name="cb">remember me
	<input type="submit" name="">
</form>
<html>
<head>
 <title></title>
 <script type="text/javascript">
  function searchdata(a)
  {
   xmlhttp = new XMLHttpRequest();
   xmlhttp.onreadystatechange=function(){
            document.getElementById("res").innerHTML=xmlhttp.responseText;   
   }
   xmlhttp.open("POST","ajax.php?q="+a,true);
   xmlhttp.send();
  }

 </script>
</head>
<body>
 <input type="text" id="txt1" placeholder="enter any char to search" onkeyup="searchdata(this.value)" />
  <div id="res"></div>
</body>
</html>
