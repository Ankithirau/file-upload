<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post">
<input type="" name="em">
<input type="" name="ps">
<input type="submit" name="cb">
</form>
</body>
</html>
<?php
 session_start();
 $em=$_REQUEST['em'];
 $pass=$_REQUEST['ps'];
 $ch=$_REQUEST['cb'];
 $conn=mysqli_connect("localhost","root","","test");
 $sel=mysqli_query($conn,"select * from student where email='$em'and password='$pass'");
 if(mysqli_fetch_row($sel)>0)
 {
    $_SESSION['email']=$em;
    $_SESSION['password']=$pass;
    if(isset($_REQUEST['ch']))
	{
	setcookie('cid',$em,time()+60);
    setcookie('cpass',$pass,time()+60);
    }    
    header("loginphp.php");
 }
 else
 {
 	echo "error password is not match";
 }


?>