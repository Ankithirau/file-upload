<html>
<head>
	<title></title>
</head>
<body>
<form action="myfile.php" method="post"  enctype="multipart/form-data">

Enter Description:-  <br>

<textarea rows="5" cols="20" name="txt1"></textarea><br><br>
<br>
<input type="file" name="f"/><br><br>
<input type="submit" name="btnsubmit" value="click"  />
</form>
</body>
</html>
<table>
<?php

$conn = mysqli_connect('localhost',"root","","6to7");
$sel=mysqli_query($conn,"select * from fileuploads");
while($x=mysqli_fetch_array($sel))
{
	?> 
     <tr><td>
     <img src="uploads/<?php echo $x[1]; ?>" height="100" width="200"></td><td><span><?php echo $x[2]?></span></td></tr>
	<?php
}

?>
</table>