<?php
 session_start();
 $em=$_REQUEST['em'];
 $pass=$_REQUEST['ps'];
 
 $conn=mysqli_connect("localhost",'root','','6to7');
 $sel=mysqli_query($conn,"select * from Student where semail='$em'and spass='$pass'");
 if(mysqli_fetch_row($sel)>0)
 {
    $_SESSION['email']=$em;
    $_SESSION['password']=$pass;
    if($_SESSION['email']!=null && $_SESSION['password']!=null)
       header("location:Dashboard/");
 }
 else
 {
 	echo "error password is not match";
 }

 
?>