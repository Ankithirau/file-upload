<form action="loginphp.php">
	<label>email</label><br>
	<input type="" name="em"><br>
	<label>password</label><br>
	<input type="" name="ps"><br>
	<input type="submit" name="">
</form>