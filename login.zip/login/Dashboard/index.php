<h1>This is my DASHBOARD</h1>  
<?php
session_start();
if($_SESSION['email']==null && $_SESSION['password']==null)
   header("location:../login.php");
else
{
$e=$_SESSION['email'];
$p=$_SESSION['password'];
$conn=mysqli_connect("localhost",'root','','6to7');
 $sel=mysqli_query($conn,"select * from Student where semail='$e'and spass='$p'");
 if($x=mysqli_fetch_array($sel))
 {
   echo $x[1]." ".$x[2]." ".$x[3];
 }
}
?>
<a href="logout.php">logout</a>